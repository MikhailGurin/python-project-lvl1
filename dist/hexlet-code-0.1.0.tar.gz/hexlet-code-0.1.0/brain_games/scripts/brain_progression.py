#!/usr/bin/env python
"""Игра Арифметическая прогрессия."""

from brain_games.games.progression import start


def main():
    """Основная функция."""
    start()


if __name__ == '__main__':
    main()

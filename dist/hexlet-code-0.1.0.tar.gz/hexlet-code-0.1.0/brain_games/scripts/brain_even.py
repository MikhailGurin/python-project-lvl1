#!/usr/bin/env python
"""Игра проверка на чётность."""

from brain_games.games.even import even_game


def main():
    """Основная функция."""
    even_game()


if __name__ == '__main__':
    main()

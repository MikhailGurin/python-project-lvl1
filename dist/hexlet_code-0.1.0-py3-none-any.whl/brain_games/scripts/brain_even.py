#!/usr/bin/env python
"""Игра проверка на чётность."""

from games.even import start


def main():
    """Основная функция."""
    start()


if __name__ == '__main__':
    main()

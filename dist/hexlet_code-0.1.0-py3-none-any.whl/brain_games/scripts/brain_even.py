#!/usr/bin/env python
"""Игра проверка на чётность."""

from brain_games.games.even import start


def main():
    """Основная функция."""
    start()


if __name__ == '__main__':
    main()

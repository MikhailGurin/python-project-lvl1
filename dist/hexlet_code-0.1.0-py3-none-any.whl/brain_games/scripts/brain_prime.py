#!/usr/bin/env python
"""Игра Простое ли число?"""

from brain_games.games.prime import start


def main():
    """Основная функция."""
    start()


if __name__ == '__main__':
    main()

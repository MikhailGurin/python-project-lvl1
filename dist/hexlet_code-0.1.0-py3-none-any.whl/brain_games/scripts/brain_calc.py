#!/usr/bin/env python
"""Игра калькулятор."""

from brain_games.games.calc import start


def main():
    """Основная функция."""
    start()


if __name__ == '__main__':
    main()

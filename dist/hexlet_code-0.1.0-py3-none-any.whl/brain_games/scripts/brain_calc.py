#!/usr/bin/env python
"""Игра калькулятор."""

from games.calc import start


def main():
    """Основная функция."""
    start()


if __name__ == '__main__':
    main()

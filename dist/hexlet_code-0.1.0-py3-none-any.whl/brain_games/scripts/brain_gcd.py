#!/usr/bin/env python
"""Игра найти НОД."""

from games.gcd import start


def main():
    """Основная функция."""
    start()


if __name__ == '__main__':
    main()
